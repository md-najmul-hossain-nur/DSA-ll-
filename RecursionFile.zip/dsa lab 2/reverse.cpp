#include <iostream>
using namespace std;

int reverse_int(int n ,int r=0)
{

if(n==0)
    return r;
else
    return reverse_int(n/10,r*10+n%10);

}


int main()
{
    int n;
    cout << "Enter a number: ";
    cin >> n;
int reversed =reverse_int(n);
    cout << "Reversed number is: " << reverse_int(n) << endl;

    return 0;
}

